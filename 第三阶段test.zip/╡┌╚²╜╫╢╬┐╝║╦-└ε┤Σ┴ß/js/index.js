window.addEventListener("load", function () {
    //   获取元素
    var nav_ul = document.querySelector('#nav_ul');
    var nav_li = nav_ul.querySelectorAll('li');
    var playbook = document.querySelector(".playbook");
    var _d = playbook.querySelector("#_d");
    var _h = playbook.querySelector("#_h");
    var _m = playbook.querySelector("#_m");
    var _s = playbook.querySelector("#_s");
    // 功能一：导航栏点击对应li后文字高亮
    // 通过循环给nav_ul导航栏添加点击事件
    // 排他思想，先干掉所有人，在给自己添加类，使其对应文字高亮
    for (var i = 0; i < nav_li.length; i++) {
        nav_li[i].onclick = function () {
            for (var i = 0; i < nav_li.length; i++) {
                nav_li[i].className = "";
            }
            this.className = "active";
        }
    };
    // 功能二：倒计时
    // 用户输入的总时间
    var inputTime = +new Date('2022-2-1 19:09:09');
    // 为了避免第一次页面刷新，因为定时器设置的时间间隔而出现的空白，先调用一次计算时间的countTime()函数
    countTime();
    // 开启定时器
    setInterval(countTime, 1000);
    function countTime() {
        // 获得当前系统时间
        var nowTime = +new Date();
        // 计算剩余的总秒数
        var time = (inputTime - nowTime) / 1000;
        // 分别计算出剩余天数、小时、分钟、秒数，并它们给对应的盒子里
        var day = parseInt(time / 60 / 60 / 24);
        _d.innerHTML = day + '天';
        var h = parseInt(time / 60 / 60 % 24);
        h = h < 10 ? "0" + h : h;
        _h.innerHTML = h + '时';
        var m = parseInt(time / 60 % 60);
        m = m < 10 ? "0" + m : m;
        _m.innerHTML = m + '分';
        var s = parseInt(time % 60);
        s = s < 10 ? "0" + s : s;
        _s.innerHTML = s + '秒';
    };
    // 功能三：左侧导航栏
    //获取元素
    var l_nav = document.querySelector(".nav .all-class");
    var lis = l_nav.querySelector(".show:nth-child(1)").children;
    // 通过for循环给每个侧边导航栏的li添加鼠标移入和移除事件
    for (var i = 0; i < lis.length; i++) {
        // 当鼠标移入某个li时，显示对应的显示侧边栏
        lis[i].addEventListener("mouseover", function () {
            // console.log(this.children[1]);
            this.children[1].style.display = "block";
        });
        // 当鼠标移出某个li时，显示对应的隐藏侧边栏
        lis[i].addEventListener("mouseout", function () {
            this.children[1].style.display = "none";
        });
    };

    // 功能四：轮播图模块
    // 1、获取元素
    var banner = document.querySelector(".banner_img")
    var banner_ul = document.querySelector("#publish-copy");
    var circle = document.querySelector(".b_dot");
    var bannerWidth = banner.offsetWidth;
    // 2、动态生成小圆圈  有几张图片，就生成几个小圆圈
    for (var i = 0; i < banner_ul.children.length; i++) {
        // 创建一个a
        var a = document.createElement("a");
        // a.href = "javascript:void(0);";
        // 给小圆圈添加索引号，便于点击小圆圈的切换对应的图片
        a.setAttribute("index", i);
        // 把创建的a标签添加到对应div中
        circle.appendChild(a);
        // 3、直接在生成小圆圈的同时直接绑定点击事件
        a.addEventListener("click", function () {
            // 排他思想
            for (var i = 0; i < circle.children.length; i++) {
                circle.children[i].className = '';
            }
            // 留下我自己  当前的小li 设置current 类名
            this.className = 'on';
            // 4、点击小圆圈后移动图片
            // 获取当前圆圈的索引号
            var index = this.getAttribute("index");
            // 当点击了某个小圆圈时，要把这个圆圈的索引号给 num和自动轮播时小圆圈的计数circle_num
            num = index;
            circle_num = index;
            // console.log(-index * bannerWidth);
            animate(banner_ul, -index * bannerWidth);
        })
    }
    // 把circle盒子里面的第一个小a设置类名为 on，显示高亮
    circle.children[0].className = 'on';
    // 5、克隆第一张图片(li)放到ul 最后面
    var first = banner_ul.children[0].cloneNode(true);
    banner_ul.appendChild(first);
    // 6、设置定时器，实现自动播放
    // 图片滚动张数
    var num = 0;
    // 自动播放时下面的小圆圈要跟着变动，用circle_num计数圆圈滚动的次数
    var circle_num = 0;
    var timer = setInterval(function () {
        // 如果走到了最后一张赋值的图片时，应该从头开始，把ul与num归零 
        if (num == banner_ul.children.length - 1) {
            banner_ul.style.left = 0;
            num = 0;
        }
         num++;
        animate(banner_ul, -num * bannerWidth);
        // 7、自动轮播的时候下面的小圆圈的样式随着变动
        // 如果小圆圈走到了最后，就从头开始把circle_num归零
        circle_num++;
        if (circle_num == circle.children.length) {
            circle_num = 0;
        }
        // 排他思想
        for (var i = 0; i < circle.children.length; i++) {
            circle.children[i].className = '';
        }
        circle.children[circle_num].className = 'on';
    }, 2000);


    // 8、当鼠标鼠标进入轮播图部分停止轮播
    banner.addEventListener("mouseover",function(){
        clearInterval(timer);
    });
    // 9、当鼠标离开轮播图部分又开始轮播
    banner.addEventListener("mouseout",function(){
       clearInterval(timer);
       timer = setInterval(function () {
           // 如果走到了最后一张赋值的图片时，应该从头开始，把ul与num归零 
           if (num == banner_ul.children.length - 1) {
               banner_ul.style.left = 0;
               num = 0;
           }
           num++;
           animate(banner_ul, -num * bannerWidth);
           // 7、自动轮播的时候下面的小圆圈的样式随着变动
           // 如果小圆圈走到了最后，就从头开始把circle_num归零
           circle_num++;
           if (circle_num == circle.children.length) {
               circle_num = 0;
           }
           // 排他思想
           for (var i = 0; i < circle.children.length; i++) {
               circle.children[i].className = '';
           }
           circle.children[circle_num].className = 'on';
       }, 2000);

    })

})